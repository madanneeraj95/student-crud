package com.app.entities;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name="student")
@Getter
@Setter
public class Student extends BaseEntity {
	@Column(length=20)
	private String firstName;
	@Column(length=10)
	private int rollno;
	@Column(length=20)
	private String lastName;
	public Student() {
		
	}
	public Student( long id,String firstName, int rollno, String lastName) {
		super();
		this.id=id;
		this.firstName = firstName;
		this.rollno = rollno;
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	 public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }
	@Override
	public String toString() {
		return "Student [firstName=" + firstName + ", rollno=" + rollno + ", lastName=" + lastName + "]";
	}

}
