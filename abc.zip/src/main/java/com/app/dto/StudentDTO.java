package com.app.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class StudentDTO {
	 @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	
    private long id;
	private String firstName;
	private int rollno;
	private String lastName;
	public StudentDTO(long id, String firstName, int rollno, String lastName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.rollno = rollno;
		this.lastName = lastName;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
