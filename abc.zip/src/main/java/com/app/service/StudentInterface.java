package com.app.service;

import com.app.entities.Student;

import java.util.List;
import java.util.Optional;

public interface StudentInterface {

    List<Student> getAllStudents();

    Optional<Student> getStudentById(Long id);

    Student saveStudent(Student student);

    void deleteStudent(Long id);

    Student updateStudent(Student student);
}

